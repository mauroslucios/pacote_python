# __init__.py
from .calculadora import Calculadora


__all__ = ['Calculadora']
